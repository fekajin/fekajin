﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumTable
{
    public class Task
    {
        public string TaskYazarı { get; set; }
        public int Task_Durumu { get; set; }
        public string Task_Aciklamasi { get; set; }
        public string Task_ArkaPlanRengi { get; set; }
        public string Task_Baslik { get; set; }
        public string Task_Tarih { get; set; }
        public int TaskKonumuX { get; set; }
        public int TaskKonumuY { get; set; }
        public int Story_ID { get; set; }
        
    }
}
