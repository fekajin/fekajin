﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScrumTable
{
    public partial class frmStoryEkle : Form
    {
        public frmStoryEkle()
        {
            InitializeComponent();
        }

        private void btnStoryEkle_Click(object sender, EventArgs e)
        {
           
            frmMain frm = frmMain.GetInstance;
            Story Story = new Story();
            Button StoryEkle = new Button();
            Random Rnd = new Random();
            List<PictureBoxInfo> data = SQLHelper.Select();
            

            StoryEkle.BackColor = Color.FromArgb(Rnd.Next(0, 128), Rnd.Next(0, 128), Rnd.Next(0, 128)); //random renk seçimi
            foreach (Panel Panel in frm.Controls.OfType<Panel>())
            {
                if (Panel.Name == "panel5")
                {
                    foreach (Panel Panels in Panel.Controls.OfType<Panel>())
                    {
                        if (Panels.Name == "pnlStory") 
                        {
                            Panels.Refresh();
                            StoryEkle.Location = SQLHelper.SonItemiGetir(); //son itemi getir
                        }
                    }
                }
            }
            if (data.Count == 0)
            {
                Story.StoryKonumuX = StoryEkle.Location.X + 5;
            }
            else
            Story.StoryKonumuX = StoryEkle.Location.X;
            Story.StoryKonumuY = StoryEkle.Location.Y;
            Story.Story_Aciklamasi = txtDescription.Text;
            Story.Story_Adı = txtStory_Name.Text;
            Story.Story_Tarih = DateTime.Now.Date.ToString("dd/MM/yy");
            Story.Story_Rengi = StoryEkle.BackColor.GetHashCode().ToString();
            Story.Story_Yazarı = txtStoryAuthor.Text;

            SQLHelper.StoryGiris(Story);
            Application.Restart();
            this.Close();
        }

        private void frmStoryEkle_Load(object sender, EventArgs e)
        {

        }
    }
}
