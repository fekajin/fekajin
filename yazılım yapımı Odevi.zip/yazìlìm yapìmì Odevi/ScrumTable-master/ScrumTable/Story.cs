﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumTable
{
    public class Story
    {
        public string Story_Aciklamasi { get; set; }
        public string Story_Rengi { get; set; }
        public string Story_Adı { get; set; }
        public string Story_Yazarı { get; set; }
        public string Story_Tarih { get; set; }
        public int StoryKonumuX { get; set; }
        public int StoryKonumuY { get; set; }

    }
}
