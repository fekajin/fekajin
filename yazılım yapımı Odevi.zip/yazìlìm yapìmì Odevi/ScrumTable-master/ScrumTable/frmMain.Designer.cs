﻿namespace ScrumTable
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnlNotStarted = new System.Windows.Forms.Panel();
            this.pnlInProgress = new System.Windows.Forms.Panel();
            this.pnlDone = new System.Windows.Forms.Panel();
            this.pnlStory = new System.Windows.Forms.Panel();
            this.btnStoryEkle = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btnTaskEkle = new System.Windows.Forms.Button();
            this.btnBaglanti = new System.Windows.Forms.Button();
            this.btnVeriSil = new System.Windows.Forms.Button();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.AutoSize = true;
            this.panel5.Controls.Add(this.pnlNotStarted);
            this.panel5.Controls.Add(this.pnlInProgress);
            this.panel5.Controls.Add(this.pnlDone);
            this.panel5.Controls.Add(this.pnlStory);
            this.panel5.Location = new System.Drawing.Point(40, 177);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1236, 738);
            this.panel5.TabIndex = 1;
            // 
            // pnlNotStarted
            // 
            this.pnlNotStarted.AllowDrop = true;
            this.pnlNotStarted.AutoSize = true;
            this.pnlNotStarted.BackColor = System.Drawing.Color.CornflowerBlue;
            this.pnlNotStarted.Location = new System.Drawing.Point(314, 3);
            this.pnlNotStarted.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlNotStarted.Name = "pnlNotStarted";
            this.pnlNotStarted.Size = new System.Drawing.Size(300, 731);
            this.pnlNotStarted.TabIndex = 3;
            this.pnlNotStarted.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel_DragDrop);
            this.pnlNotStarted.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel_DragEnter);
            // 
            // pnlInProgress
            // 
            this.pnlInProgress.AllowDrop = true;
            this.pnlInProgress.AutoSize = true;
            this.pnlInProgress.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlInProgress.Location = new System.Drawing.Point(622, 3);
            this.pnlInProgress.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlInProgress.Name = "pnlInProgress";
            this.pnlInProgress.Size = new System.Drawing.Size(300, 731);
            this.pnlInProgress.TabIndex = 4;
            this.pnlInProgress.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel_DragDrop);
            this.pnlInProgress.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel_DragEnter);
            // 
            // pnlDone
            // 
            this.pnlDone.AllowDrop = true;
            this.pnlDone.AutoSize = true;
            this.pnlDone.BackColor = System.Drawing.Color.LightSkyBlue;
            this.pnlDone.Location = new System.Drawing.Point(932, 3);
            this.pnlDone.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlDone.Name = "pnlDone";
            this.pnlDone.Size = new System.Drawing.Size(300, 731);
            this.pnlDone.TabIndex = 5;
            this.pnlDone.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel_DragDrop);
            this.pnlDone.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel_DragEnter);
            // 
            // pnlStory
            // 
            this.pnlStory.AutoSize = true;
            this.pnlStory.BackColor = System.Drawing.Color.DodgerBlue;
            this.pnlStory.Location = new System.Drawing.Point(4, 3);
            this.pnlStory.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlStory.Name = "pnlStory";
            this.pnlStory.Size = new System.Drawing.Size(300, 731);
            this.pnlStory.TabIndex = 2;
            // 
            // btnStoryEkle
            // 
            this.btnStoryEkle.Location = new System.Drawing.Point(354, 43);
            this.btnStoryEkle.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnStoryEkle.Name = "btnStoryEkle";
            this.btnStoryEkle.Size = new System.Drawing.Size(300, 57);
            this.btnStoryEkle.TabIndex = 2;
            this.btnStoryEkle.Text = "Story Ekle";
            this.btnStoryEkle.UseVisualStyleBackColor = true;
            this.btnStoryEkle.Click += new System.EventHandler(this.btnStoryEkle_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button3.Location = new System.Drawing.Point(40, 129);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(304, 43);
            this.button3.TabIndex = 4;
            this.button3.Text = "STORY";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button4.Location = new System.Drawing.Point(352, 126);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(300, 43);
            this.button4.TabIndex = 5;
            this.button4.Text = "NOT STARTED";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button5.Location = new System.Drawing.Point(662, 129);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(300, 43);
            this.button5.TabIndex = 6;
            this.button5.Text = "IN PROGRESS";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.button6.Location = new System.Drawing.Point(970, 129);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(300, 43);
            this.button6.TabIndex = 7;
            this.button6.Text = "DONE";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // btnTaskEkle
            // 
            this.btnTaskEkle.Location = new System.Drawing.Point(662, 43);
            this.btnTaskEkle.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnTaskEkle.Name = "btnTaskEkle";
            this.btnTaskEkle.Size = new System.Drawing.Size(300, 57);
            this.btnTaskEkle.TabIndex = 8;
            this.btnTaskEkle.Text = "Task Ekle";
            this.btnTaskEkle.UseVisualStyleBackColor = true;
            this.btnTaskEkle.Click += new System.EventHandler(this.btnTaskEkle_Click);
            // 
            // btnBaglanti
            // 
            this.btnBaglanti.Location = new System.Drawing.Point(40, 43);
            this.btnBaglanti.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.btnBaglanti.Name = "btnBaglanti";
            this.btnBaglanti.Size = new System.Drawing.Size(272, 57);
            this.btnBaglanti.TabIndex = 10;
            this.btnBaglanti.Text = "Bağlantıyı Aç";
            this.btnBaglanti.UseVisualStyleBackColor = true;
            this.btnBaglanti.Click += new System.EventHandler(this.btnBaglanti_Click);
            // 
            // btnVeriSil
            // 
            this.btnVeriSil.Location = new System.Drawing.Point(972, 43);
            this.btnVeriSil.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnVeriSil.Name = "btnVeriSil";
            this.btnVeriSil.Size = new System.Drawing.Size(300, 57);
            this.btnVeriSil.TabIndex = 11;
            this.btnVeriSil.Text = "Veriyi Sil";
            this.btnVeriSil.UseVisualStyleBackColor = true;
            this.btnVeriSil.Click += new System.EventHandler(this.btnVeriSil_Click_1);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(1324, 932);
            this.Controls.Add(this.btnVeriSil);
            this.Controls.Add(this.btnBaglanti);
            this.Controls.Add(this.btnTaskEkle);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnStoryEkle);
            this.Controls.Add(this.panel5);
            this.Font = new System.Drawing.Font("Magneto", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmMain";
            this.Text = "SCRUM TABLE";
            this.Load += new System.EventHandler(this.frmMain_Load_1);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnlNotStarted;
        private System.Windows.Forms.Panel pnlInProgress;
        private System.Windows.Forms.Panel pnlDone;
        private System.Windows.Forms.Panel pnlStory;
        private System.Windows.Forms.Button btnStoryEkle;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnTaskEkle;
        private System.Windows.Forms.Button btnBaglanti;
        private System.Windows.Forms.Button btnVeriSil;
    }
}

