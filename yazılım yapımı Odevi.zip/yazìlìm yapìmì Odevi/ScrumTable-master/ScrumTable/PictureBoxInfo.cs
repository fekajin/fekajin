﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ScrumTable
{
    public class PictureBoxInfo
    {
        public Point PB_Konumu { get; set; }
        public Size PB_Boyut { get; set; }
        public string PB_ArkaPlan { get; set; }
        public int Story_ID { get; set; }
        public int Story_Task_Count { get; set; }
        public int Task_ID { get; set; }
        public int Task_Durumu { get; set; }
        public string Story_Aciklamasi { get; set; }
        public string Task_Tarihi { get; set; }
        public string Task_Yazari { get; set; }
        public string Story_EklenmeTarihi { get; set; }
        public string Story_Adı { get; set; }
        public string Task_Basligi { get; set; }
        public string Story_Yazari { get; set; }
    }
}
